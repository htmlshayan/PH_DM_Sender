import random
import re

def resolve_spintax(text):
    while True:
        match = re.search(r'\{([^{}]*)\}', text)
        if not match:
            break
        choices = match.group(1).split('|')
        replacement = random.choice(choices)
        text = text[:match.start()] + replacement + text[match.end():]
    return text

if __name__ == "__main__":
    spintax_template = "{Hello|Hi|Hey there}, {I hope you are well|hope all is well with you|I hope you're doing great}. 💙 {As a consultant specializing in|Specializing in|As an expert in} {the promotion of premium adult content|premium adult content promotion|maximizing adult platform growth}, {I can help you|my goal is to help you|I can assist you to} {optimize and boost your income|maximize and scale your earnings|boost your monthly revenue} {on your platforms|on your channels|on your pages} {(OnlyFans, Pornhub Premium, etc.)}. {Our service is} {without any upfront fees|with zero upfront costs|completely free to start} - {only a moderate commission|just a reasonable percentage|only a fair commission} {on the additional earnings generated}. {If you are interested and would like to discuss this in more detail, please let me know}. {Nice day to youu|Have a wonderful day|Wishing you a great day}. {Sincerely|Best regards|Talk soon}."
    
    # Generate and print a few examples to show the randomization
    print("--- Spintax Examples ---")
    for i in range(5):
        result = resolve_spintax(spintax_template)
        print(f"\nExample {i+1}:\n{result}")
